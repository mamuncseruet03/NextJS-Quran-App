type Video = {
  id: string;
  title: string;
  channel: string;
  views: string;
  thumbnail: string;
};

export default function VideoCard({ video }: { video: Video }) {
  return (
    <div className="cursor-pointer">
      {/* Thumbnail */}
      <div className="aspect-video w-full overflow-hidden rounded-lg bg-gray-200">
        <img
          src={video.thumbnail}
          alt={video.title}
          className="h-full w-full object-cover hover:scale-105 transition-transform"
        />
      </div>

      {/* Info */}
      <div className="mt-3 flex gap-3">
        <div className="h-9 w-9 rounded-full bg-gray-300" />

        <div>
          <h3 className="font-medium leading-snug line-clamp-2">
            {video.title}
          </h3>
          <p className="text-sm text-gray-500">{video.channel}</p>
          <p className="text-sm text-gray-500">{video.views} views</p>
        </div>
      </div>
    </div>
  );
}
