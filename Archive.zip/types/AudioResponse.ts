interface AudioResponse {
  url?: string;
  duration?: number;
  format?: string;
  segments?: [];
}

export default AudioResponse;
