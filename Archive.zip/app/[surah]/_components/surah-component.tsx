"use client";

import { currentFontAtom } from "@/atoms";
import ButtonGroup from "@/components/button-group";
import { Card, CardHeader } from "@/components/ui/card";
import { SurahType, TafseerListType } from "@/types";
import { useAtomValue } from "jotai";
import AudioPlayer from "./audio-player";
import AyahNumber from "./ayah-number";
import ScrollProgressBar from "./scroll-progress-bar";
import TafseerComponent from "./tafseer-component";
import { Separator } from "@/components/ui/separator";
import Verse from "@/types/Verse";

export default function SurahComponent({
  surah,
  TafseerList,
}: {
  surah: Verse[];
  TafseerList: TafseerListType;
}) {
  const font = useAtomValue(currentFontAtom);

  return (
    <>
      <ScrollProgressBar />
      <div className="w-full space-y-14">
        {/* <header className="flex justify-between items-center gap-4 sticky top-1 bg-background z-50 pb-2 pt-5">
          <h1
            className="text-3xl md:text-5xl text-center pb-6"
            style={{ fontFamily: `var(--font-${font})` }}
          >
            {surah[0].juzNumber}
          </h1>

          <ButtonGroup />
        </header> */}
        {surah &&
          surah.map((ayah) => (
            <div className="flex items-center gap-2">
              {ayah.verseNumber !== 1 && (
                <Card>
                  <CardHeader className="flex-row gap-2 items-center text-3xl rtl py-10">
                    <div
                      className="text-2xl text-center w-full"
                      style={{ fontFamily: `var(--font-${font})` }}
                    >
                      {ayah.textImlaeiSimple}
                    </div>
                  </CardHeader>
                </Card>
              )}
              {ayah.words.map((word) => (
                <div
                  className="flex flex-col gap-2 items-start text-3xl rtl cursor-default p-4 "
                  key={word.numberInSurah}
                >
                  <div className="flex flex-col gap-2">
                    <span
                      className=" hover:bg-yellow-50 transition-all duration-300 ease-in-out"
                      style={{ fontFamily: `var(--font-${font})` }}
                    >
                      {word.text}
                    </span>
                    <span
                      className="-mt-4 leading-[4rem] tracking-wide"
                      style={{ fontFamily: `var(--font-${font})` }}
                    >
                      {word.translationBn?.text}
                    </span>
                    {/* <span
                      className="-mt-4 leading-[4rem] tracking-wide"
                      style={{ fontFamily: `var(--font-${font})` }}
                    >
                      {word.translation?.text}
                    </span> */}
                  </div>
                  <div className="flex flex-row gap-2 w-full items-center">
                    <Separator orientation="vertical" className="h-4" />
                    <AudioPlayer
                      src={word.audioUrl}
                      className="w-full"
                      numberInSurah={word.numberInSurah}
                      numberOfAyahs={word.numberOfAyahs}
                    />
                  </div>
                </div>
              ))}
            </div>
          ))}
      </div>
    </>
  );
}
