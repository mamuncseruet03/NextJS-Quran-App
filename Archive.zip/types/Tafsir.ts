interface Tafsir {
  id?: number;
  resourceId?: number;
  text?: string;
  resourceName?: string;
  languageName?: string;
}

export default Tafsir;
